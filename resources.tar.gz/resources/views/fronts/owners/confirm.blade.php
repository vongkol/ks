@extends('layouts.front')
@section('content')
<!-- sign-up form -->
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <p></p>
                <h3 class="text-success text-center">Thanks for your registration. Please check your email to verify!</h3>
                <hr>
            </div>
        </div>
    </div>
</div>
@endsection