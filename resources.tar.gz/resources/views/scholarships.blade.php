@extends('layouts.front')
@section('content')
    <div class="box-head top-head">
        <h3 class="head-title text-center">Scholarship List</h3>
    </div>
    <div class="container">
        <p></p>
        <div class="row">
            <div class="col-md-3">
        
            <div id='cssmenu'>
                        <ul>
                            <li class='has-sub'><a href='#'>CATEGORY</a>
                                <ul>
                                    <li><a href='#'>Smart Phones</a></li>
                                    <li><a href='#'>Cell Phones</a></li>
                                    <li class='last'><a href='#'>Android Phones</a></li>
                                </ul>
                            </li>
                        </ul>
                            
                           
                    </div>
                    <!-- /.sidenav-section -->
            </div>
            <div class="col-lg-9 col-md-9 col-sm-">
           
                    
        
                        <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="product-block">
                                <div class="product-img"><a href="{{url('product-single')}}"><img src="./images/s1.jpeg" width="100%" alt=""></a></div>
                                <div class="product-content">
                                    <h5 align="justify">
                                        <a href="#" class="product-title"> Lorem ipsum dolor sit amet consectetur
                                        adipisicing elit. Harum aut exercitationem vitae voluptates impedit ipsam
                                        iste doloremque ratione odio eligendi vero sint perferendis reprehenderit
                                        adipisci accusamus, dolorem, recusandae beatae delectus.</a></h5>
                                </div>
                            </div>
                        </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="product-block">
 <div class="product-img"><a href="{{url('product-single')}}"><img src="./images/s2.jpeg" width="100%" alt=""></a></div>
                                <div class="product-content">
                            
                                        <h5 align="justify">
                                            <a href="#" class="product-title"> Lorem ipsum dolor sit amet consectetur
                                            adipisicing elit. Harum aut exercitationem vitae voluptates impedit ipsam
                                            iste doloremque ratione odio eligendi vero sint perferendis reprehenderit
                                            adipisci accusamus, dolorem, recusandae beatae delectus.</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="product-block">
                                <div class="product-img"><a href="{{url('product-single')}}"><img src="./images/s3.jpeg" width="100%" alt=""></a></div>
                                <div class="product-content">
                                    
                                        <h5 align="justify">
                                            <a href="#" class="product-title"> Lorem ipsum dolor sit amet consectetur
                                            adipisicing elit. Harum aut exercitationem vitae voluptates impedit ipsam
                                            iste doloremque ratione odio eligendi vero sint perferendis reprehenderit
                                            adipisci accusamus, dolorem, recusandae beatae delectus.</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="product-block">
                                <div class="product-img"><a href="{{url('product-single')}}"><img src="./images/s1.jpeg" width="100%" alt=""></a></div>
                                <div class="product-content">
                                    <h5 align="justify">
                                        <a href="#" class="product-title"> Lorem ipsum dolor sit amet consectetur
                                        adipisicing elit. Harum aut exercitationem vitae voluptates impedit ipsam
                                        iste doloremque ratione odio eligendi vero sint perferendis reprehenderit
                                        adipisci accusamus, dolorem, recusandae beatae delectus.</a></h5>
                                </div>
                            </div>
                        </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="product-block">
                                 <div class="product-img"><a href="{{url('product-single')}}"><img src="./images/s2.jpeg" width="100%" alt=""></a></div>
                                <div class="product-content">
                            
                                        <h5 align="justify">
                                            <a href="#" class="product-title"> Lorem ipsum dolor sit amet consectetur
                                            adipisicing elit. Harum aut exercitationem vitae voluptates impedit ipsam
                                            iste doloremque ratione odio eligendi vero sint perferendis reprehenderit
                                            adipisci accusamus, dolorem, recusandae beatae delectus.</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="product-block">
                                <div class="product-img"><a href="{{url('product-single')}}"><img src="./images/s3.jpeg" width="100%" alt=""></a></div>
                                <div class="product-content">
                                    
                                        <h5 align="justify">
                                            <a href="#" class="product-title"> Lorem ipsum dolor sit amet consectetur
                                            adipisicing elit. Harum aut exercitationem vitae voluptates impedit ipsam
                                            iste doloremque ratione odio eligendi vero sint perferendis reprehenderit
                                            adipisci accusamus, dolorem, recusandae beatae delectus.</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
           
       
        </div>
    </div>
    <p></p>
    @endsection