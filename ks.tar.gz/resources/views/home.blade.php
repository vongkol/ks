@extends('layouts.dashboard')

@section('content')
<div class="row">
   <div class="col-sm-12">
       <p></p>
       <h1 class="text-center">Welcome to KS Admin</h1>
       
   </div>
@endsection
