@extends('layouts.product')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h3 class="text-primary text-center">Manage Your Product</h3>
                <hr>
            </div>
        </div>
    </div>
@endsection