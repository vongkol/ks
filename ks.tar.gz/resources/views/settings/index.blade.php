@extends("layouts.setting")
@section("content")
    <div class="row">
        <div class="col-sm-12">
            <h2 class="text-primary">This is settings section!</h2>
        </div>
    </div>
@endsection